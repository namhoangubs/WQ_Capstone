from __future__ import annotations

import os
from itertools import product
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
from numpy.random import default_rng
from pandas import DataFrame, read_csv
from hmmlearn.hmm import GaussianHMM


BASE_DIR = Path(r"C:\Users\namho\Desktop\Previous PC\World Quant\Thesis\Replication")
INPUT_DIR = BASE_DIR / "Inputs"


def _num_params_gaussian_hmm(n_states: int, n_features: int, covariance_type: str = "full") -> int:
    """
    Number of free parameters for a GaussianHMM with:
      - startprob_ (sum to 1) -> n_states - 1
      - transmat_ (rows sum to 1) -> n_states*(n_states-1)
      - means_ -> n_states*n_features
      - covars_:
          full: n_states * n_features*(n_features+1)/2
          diag: n_states * n_features
          spherical: n_states
          tied: n_features*(n_features+1)/2  (shared across states)

    This mirrors the usual HMM information-criteria parameter counting.
    """
    k = (n_states - 1) + (n_states * (n_states - 1)) + (n_states * n_features)

    if covariance_type == "full":
        k += n_states * (n_features * (n_features + 1) // 2)
    elif covariance_type == "diag":
        k += n_states * n_features
    elif covariance_type == "spherical":
        k += n_states
    elif covariance_type == "tied":
        k += n_features * (n_features + 1) // 2
    else:
        raise ValueError(f"Unsupported covariance_type: {covariance_type}")

    return int(k)


def _fit_one(
    n_states: int,
    seed: int,
    X: np.ndarray,
    covariance_type: str = "full",
    n_iter: int = 10000,
    tol: float = 1e-5,
) -> Optional[Dict]:
    """
    Fit one HMM and return the same output fields as the original script.
    Returns None on ValueError (matches original behavior).
    """
    try:
        hmm = GaussianHMM(
            n_components=n_states,
            covariance_type=covariance_type,
            random_state=seed,
            n_iter=n_iter,
            tol=tol,
            implementation="scaling",
        )
        hmm.fit(X)

        # Single log-likelihood evaluation (avoid repeated scoring in aic/bic)
        ll = float(hmm.score(X))

        # Fast state counts (replaces numpy.unique(..., return_counts=True))
        states = hmm.predict(X)
        counts = np.bincount(states, minlength=n_states)
        min_count = int(counts.min())
        valid = int((counts > 0).sum()) == n_states

        # Convergence check (guard short histories)
        converged = bool(getattr(hmm.monitor_, "converged", False))

        # Information criteria (standard AIC/BIC formulas)
        n_obs = int(X.shape[0])
        k = _num_params_gaussian_hmm(
            n_states=n_states,
            n_features=int(X.shape[1]),
            covariance_type=covariance_type,
        )
        aic = 2.0 * k - 2.0 * ll
        bic = k * np.log(n_obs) - 2.0 * ll

        return {
            "N_STATES": n_states,
            "SEED": seed,
            "LL": round(ll, 2),
            "AIC": round(aic, 2),
            "BIC": round(bic, 2),
            "MIN_COUNT": min_count,
            "CONVERGED": bool(converged),
            "VALID": bool(valid),
        }

    except ValueError:
        return None


def p1_0_hmm_params():
    SEED = 42
    N_SEEDS = 10000
    TRAIN_DATE = "2009-06-02"
    FOLDER = BASE_DIR / "phase_1"

    # Progress / performance controls
    LOG_EVERY = 200  # print once per this many completed fits
    N_JOBS = max(1, (os.cpu_count() or 1) - 1)  # use all but one core by default

    seeds = sorted(default_rng(seed=SEED).choice(range(1000000), N_SEEDS, False, shuffle=False))

    exog_rets = read_csv(BASE_DIR / "processed" / "exog_rets.csv", index_col=[0], parse_dates=[0])
    n_train = int((exog_rets.index < TRAIN_DATE).sum())

    # Pre-extract numpy arrays to reduce pandas slicing overhead inside the loop
    X2 = exog_rets.iloc[:n_train][["SPXT", "LT11TRUU"]].to_numpy(dtype=float)
    X4 = exog_rets.iloc[:n_train].to_numpy(dtype=float)

    jobs: list[Tuple[int, int, np.ndarray]] = []
    for n_states, seed in product([2, 4], seeds):
        X = X2 if n_states == 2 else X4
        jobs.append((n_states, seed, X))

    params = []

    # Parallelize across CPU cores when possible
    try:
        from joblib import Parallel, delayed  # type: ignore

        results = Parallel(
            n_jobs=N_JOBS,
            prefer="processes",
            batch_size=25,
        )(delayed(_fit_one)(n_states, seed, X) for (n_states, seed, X) in jobs)

        done = 0
        for res in results:
            done += 1
            if res is not None:
                params.append(res)
            if LOG_EVERY and (done % LOG_EVERY == 0):
                print(f"Completed: {done}/{len(jobs)}")

    except Exception:
        # Fallback: single-process loop (still faster due to fewer redundant computations)
        done = 0
        for (n_states, seed, X) in jobs:
            res = _fit_one(n_states, seed, X)
            done += 1
            if res is not None:
                params.append(res)
            if LOG_EVERY and (done % LOG_EVERY == 0):
                print(f"Completed: {done}/{len(jobs)}")

    Path(FOLDER).mkdir(parents=True, exist_ok=True)
    DataFrame(params).to_csv(FOLDER / "hmm_params.csv", index=False)


if __name__ == "__main__":
    p1_0_hmm_params()
