from pandas import read_csv, concat, DataFrame
from pathlib import Path
import numpy as np

BASE_DIR = Path(r"C:\Users\namho\Desktop\Previous PC\World Quant\Thesis\Replication")
INPUT_DIR = BASE_DIR / "Inputs"

def _select_best_for_nstates(params_n_s, min_count_thresh=9):
    """
    Replicates the intent of the original script:
    - prefer high-LL seeds, but ensure each regime has enough observations (MIN_COUNT > 9)
    - gradually tighten the LL band until the constraint would be violated, then step back.
    - if *no* row satisfies MIN_COUNT > 9 at all (rare), fall back to max-LL row (so downstream code can run).
    """
    if len(params_n_s) == 0:
        return params_n_s

    # Hard feasibility check
    feasible = params_n_s[params_n_s.MIN_COUNT > min_count_thresh]
    if len(feasible) == 0:
        # Fallback: choose max LL even if MIN_COUNT is small (prevents empty best_params)
        best_ll = params_n_s.LL.max()
        return params_n_s[params_n_s.LL == best_ll][['N_STATES', 'SEED', 'MIN_COUNT']]

    max_ll = float(params_n_s.LL.max())

    # Start with all rows in-band; then tighten.
    exp = 0
    last_good = params_n_s

    while True:
        # bound = (10**exp - 1) / (10**exp) with exp=0 => 0, exp=1 => 0.9, exp=2 => 0.99, ...
        if exp == 0:
            bound = 0.0
        else:
            bound = 1.0 - 1.0 / (10.0 ** exp)

        params_b = params_n_s[params_n_s.LL > bound * max_ll]

        if len(params_b[params_b.MIN_COUNT > min_count_thresh]) >= 1:
            last_good = params_b
            exp += 1
        else:
            break

    # Choose best LL among the last band that still had at least one feasible row
    params_m_c = last_good[last_good.MIN_COUNT > min_count_thresh]
    best_ll = params_m_c.LL.max()
    return params_m_c[params_m_c.LL == best_ll][['N_STATES', 'SEED', 'MIN_COUNT']]


def p1_1_best_params():
    FOLDER = BASE_DIR / 'phase_1'

    params = read_csv(FOLDER / 'hmm_params.csv')
    # Keep the same filtering criteria as original
    params = params[params.CONVERGED & params.VALID]

    params_m_ll = []
    for n_states in sorted(params.N_STATES.unique()):
        params_n_s = params[params.N_STATES == n_states]
        chosen = _select_best_for_nstates(params_n_s, min_count_thresh=9)
        if len(chosen) > 0:
            params_m_ll.append(chosen)

    best_params = concat(params_m_ll, axis=0) if len(params_m_ll) else DataFrame(columns=['N_STATES', 'SEED', 'MIN_COUNT'])

    Path(FOLDER).mkdir(parents=True, exist_ok=True)
    DataFrame(best_params).to_csv(FOLDER / 'best_params.csv', index=False)


if __name__ == '__main__':
    p1_1_best_params()
