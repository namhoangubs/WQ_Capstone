from __future__ import annotations

import numpy as np
import pandas as pd
from pandas import read_csv, DataFrame
from hmmlearn.hmm import GaussianHMM
from matplotlib.pyplot import (
    figure,
    scatter,
    axvspan,
    axhline,
    legend,
    xlabel,
    ylabel,
    gcf,
    close,
)
from pathlib import Path


BASE_DIR = Path(r"C:\Users\namho\Desktop\Previous PC\World Quant\Thesis\Replication")
INPUT_DIR = BASE_DIR / "Inputs"


def _get_seed_or_fallback(n_states: int, folder: Path) -> int:
    """
    Prefer best_params.csv; if missing (empty selection), fall back to hmm_params.csv
    so Phase 1 can proceed instead of failing with an IndexError.
    """
    best_params_path = folder / "best_params.csv"
    if best_params_path.exists():
        best_params = read_csv(best_params_path)
        s = best_params.loc[best_params.N_STATES == n_states, "SEED"]
        if len(s) > 0:
            return int(s.iloc[0])

    # Fallback: pick best seed directly from hmm_params, matching original constraints as closely as possible
    params_all = read_csv(folder / "hmm_params.csv")
    params_ns = params_all[params_all.N_STATES == n_states]

    # Tier 1: CONVERGED & VALID
    if "CONVERGED" in params_ns.columns:
        params = params_ns[(params_ns.CONVERGED) & (params_ns.VALID)]
    else:
        params = params_ns[params_ns.VALID]

    # Tier 2: VALID only
    if len(params) == 0:
        params = params_ns[params_ns.VALID]

    # Tier 3: anything for that n_states
    if len(params) == 0:
        params = params_ns

    # Prefer MIN_COUNT > 9 if possible
    if "MIN_COUNT" in params.columns:
        feasible = params[params.MIN_COUNT > 9]
        if len(feasible) > 0:
            best_ll = feasible.LL.max()
            return int(feasible.loc[feasible.LL == best_ll, "SEED"].iloc[0])

    # Otherwise, choose max LL among whatever is available
    if len(params) > 0:
        best_ll = params.LL.max()
        return int(params.loc[params.LL == best_ll, "SEED"].iloc[0])

    raise RuntimeError(
        f"No usable HMM parameter rows found for N_STATES={n_states}. "
        f"Check that phase_1/hmm_params.csv was generated successfully."
    )


def p1_2_hmm():
    TRAIN_DATE = "2009-06-02"
    WINDOW_SIZE = 256
    FOLDER = BASE_DIR / "phase_1"

    exog_data = read_csv(BASE_DIR / "processed" / "exog_rets.csv", index_col=[0], parse_dates=[0])
    stock_rets = read_csv(BASE_DIR / "processed" / "stock_rets.csv", index_col=[0], parse_dates=[0])
    exog_px = read_csv(BASE_DIR / "processed" / "exog_px.csv", index_col=[0], parse_dates=[0])

    for n_states in [1, 2, 4]:
        exog_rets = exog_data[["SPXT", "LT11TRUU"]].copy() if n_states == 2 else exog_data.copy()

        n_train = int((exog_rets.index < TRAIN_DATE).sum())
        train_data = exog_rets.iloc[:n_train]

        seed = 0 if n_states == 1 else _get_seed_or_fallback(n_states, FOLDER)

        hmm = GaussianHMM(
            n_components=n_states,
            covariance_type="full",
            random_state=seed,
            n_iter=10000,
            tol=1e-5,
            implementation="scaling",
        )
        hmm.fit(train_data)

        # Transition matrix (does not depend on X/Q)
        A = DataFrame(hmm.transmat_)

        # NumPy extraction (needed for Q + gamma)
        X = exog_rets.to_numpy(dtype=float)

        # Decode state path (Q) with the same rolling procedure
        Q = np.empty(len(exog_rets), dtype=int)
        Q[:n_train] = hmm.predict(X[:n_train])

        n_oos = len(exog_rets) - n_train
        for j in range(1, n_oos + 1):
            end = n_train + j
            start = end - WINDOW_SIZE
            Q[end - 1] = hmm.predict(X[start:end])[-1]

        # Attach STATE labels
        stock_rets["STATE"] = Q
        exog_rets["STATE"] = Q

        # -------- Optional diagnostics artifacts (now correctly placed) --------
        # Save fitted parameters
        means = pd.DataFrame(hmm.means_, columns=exog_rets.columns.drop("STATE", errors="ignore"))
        means.to_csv(FOLDER / f"hmm_means_q{n_states}.csv", index=False)

        # Covars is 3D; save each state's covariance matrix
        for s in range(n_states):
            pd.DataFrame(
                hmm.covars_[s],
                columns=exog_rets.columns.drop("STATE", errors="ignore"),
                index=exog_rets.columns.drop("STATE", errors="ignore"),
            ).to_csv(FOLDER / f"hmm_cov_state{s}_q{n_states}.csv")

        # Training posteriors (gamma) depend on X
        gamma_train = pd.DataFrame(
            hmm.predict_proba(X[:n_train]),
            columns=[f"p_state{s}" for s in range(n_states)],
        )
        gamma_train.to_csv(FOLDER / f"hmm_posteriors_train_q{n_states}.csv", index=False)

        # Save full state sequence depends on Q
        pd.DataFrame({"DATE": exog_rets.index, "STATE": Q}).to_csv(
            FOLDER / f"hmm_states_q{n_states}.csv",
            index=False,
        )
        # ---------------------------------------------------------------------

        avg_exog_rets_q = (
            exog_rets.drop(columns=["STATE"])
            .groupby(exog_rets["STATE"])
            .mean()
            .T
        )

        avg_exog_rets_q.rename(
            index={
                "SPXT": "Stocks",
                "DBLCIX": "Commodities",
                "IBOXIG": "Corporate Credit",
                "JPEICORE": "EM Credit",
                "LT11TRUU": "Nominal Bonds",
                "LBUTTRUU": "IL Bonds",
            },
            inplace=True,
        )

        figure(figsize=(6, 3))
        plt_px = scatter(exog_px.SPXT.index[1:], exog_px.SPXT.values[1:], 0.5, Q, cmap="tab10")
        plt_w0 = axvspan(train_data.index[0], train_data.index[-1], color="grey", alpha=0.2)
        legend(
            labels=[f"Market Painter {state + 1}" for state in range(n_states)] + ["Training Window"],
            handles=plt_px.legend_elements()[0] + [plt_w0],
            prop={"size": 5},
        )
        xlabel("Time")
        ylabel("Price")
        plt_spxt_px = gcf()
        close()

        figure(figsize=(6, 3))
        plt_rets = scatter(exog_rets.SPXT.index, exog_rets.SPXT.values, 0.5, Q, cmap="tab10")
        plt_w0 = axvspan(train_data.index[0], train_data.index[-1], color="grey", alpha=0.2)
        axhline(lw=0.5, c="k")
        legend(
            labels=[f"Market Painter {state + 1}" for state in range(n_states)] + ["Training Window"],
            handles=plt_rets.legend_elements()[0] + [plt_w0],
            prop={"size": 5},
            loc="lower left",
        )
        xlabel("Time")
        ylabel("Returns")
        plt_spxt_rets = gcf()
        close()

        Path(FOLDER).mkdir(parents=True, exist_ok=True)
        round(A, 5).to_csv(FOLDER / f"hmm_trans_mat_q{n_states}.csv")
        round(avg_exog_rets_q, 5).to_csv(FOLDER / f"avg_exog_rets_q{n_states}.csv")
        stock_rets.to_csv(FOLDER / f"stock_rets_q{n_states}.csv")
        plt_spxt_px.savefig(FOLDER / f"plt_spxt_px_q{n_states}.pdf", bbox_inches="tight")
        plt_spxt_rets.savefig(FOLDER / f"plt_spxt_rets_q{n_states}.pdf", bbox_inches="tight")


if __name__ == "__main__":
    p1_2_hmm()
