from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

from hmmlearn.hmm import GaussianHMM

from scipy.stats import kstest, jarque_bera, norm
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch


BASE_DIR = Path(r"C:\Users\namho\Desktop\Previous PC\World Quant\Thesis\Replication")
PROCESSED = BASE_DIR / "processed"
PHASE1 = BASE_DIR / "phase_1"
OUTDIR = PHASE1 / "diagnostics"

TRAIN_DATE = "2009-06-02"
WINDOW_SIZE = 256


# -----------------------
# Helpers: reading seeds
# -----------------------
def _load_seed_from_best_params(n_states: int) -> int | None:
    bp = PHASE1 / "best_params.csv"
    if bp.exists():
        best_params = pd.read_csv(bp)
        s = best_params.loc[best_params.N_STATES == n_states, "SEED"]
        if len(s) > 0:
            return int(s.iloc[0])
    return None


def _candidate_seeds(n_states: int, top_k: int = 10) -> list[int]:
    """
    Seeds to try when refitting in bootstrap (robustness).
    Prefer best_params seed, then take top LL seeds from hmm_params (VALID & CONVERGED).
    """
    seeds: list[int] = []
    s0 = _load_seed_from_best_params(n_states)
    if s0 is not None:
        seeds.append(s0)

    hp = PHASE1 / "hmm_params.csv"
    if hp.exists():
        params = pd.read_csv(hp)
        params = params[(params.N_STATES == n_states) & (params.VALID)]
        # If CONVERGED exists and has rows, use it; otherwise ignore
        if "CONVERGED" in params.columns and params.CONVERGED.any():
            params = params[params.CONVERGED]
        params = params.sort_values("LL", ascending=False).head(top_k)
        seeds.extend([int(x) for x in params.SEED.values.tolist()])

    # unique, preserve order
    out = []
    seen = set()
    for s in seeds:
        if s not in seen:
            out.append(s)
            seen.add(s)
    return out


# -----------------------
# Model fit / LL
# -----------------------
def _fit_hmm_best_ll(
    n_states: int,
    X: np.ndarray,
    seed_list: list[int],
    n_iter: int = 10000,
    tol: float = 1e-5,
) -> tuple[GaussianHMM, float]:
    """
    Fit HMM with multiple initial seeds and return the best log-likelihood fit.
    This is important for bootstrap LR stability.
    """
    best_ll = -np.inf
    best_hmm = None

    for seed in seed_list:
        try:
            hmm = GaussianHMM(
                n_components=n_states,
                covariance_type="full",
                random_state=seed,
                n_iter=n_iter,
                tol=tol,
                implementation="scaling",
            )
            hmm.fit(X)
            ll = float(hmm.score(X))
            if ll > best_ll:
                best_ll = ll
                best_hmm = hmm
        except Exception:
            continue

    if best_hmm is None:
        raise RuntimeError(f"Failed to fit HMM for K={n_states} with the provided seeds.")
    return best_hmm, best_ll


def _ll_gaussian_mvn(X: np.ndarray) -> float:
    """
    MLE Gaussian log-likelihood for multivariate normal with unknown mean and covariance.
    """
    n, d = X.shape
    mu = X.mean(axis=0)
    S = np.cov(X.T, bias=False)  # sample cov (MLE uses 1/n; but LL below uses MLE if we use bias=True)
    # Use MLE covariance (divide by n) for LL consistency:
    # MLE Sigma = (1/n) sum (x-mu)(x-mu)'
    Xm = X - mu
    Sigma_mle = (Xm.T @ Xm) / n

    # numerical safety
    eps = 1e-10
    Sigma_mle = Sigma_mle + eps * np.eye(d)

    sign, logdet = np.linalg.slogdet(Sigma_mle)
    if sign <= 0:
        # fallback to slightly stronger ridge
        Sigma_mle = Sigma_mle + 1e-6 * np.eye(d)
        sign, logdet = np.linalg.slogdet(Sigma_mle)
    inv = np.linalg.inv(Sigma_mle)

    quad = np.einsum("ij,jk,ik->i", Xm, inv, Xm)  # (x-mu)' inv (x-mu)
    ll = -0.5 * np.sum(d * np.log(2 * np.pi) + logdet + quad)
    return float(ll)


def _simulate_from_gaussian(X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """
    Simulate from fitted single Gaussian (MLE) under null.
    """
    n, d = X.shape
    mu = X.mean(axis=0)
    Xm = X - mu
    Sigma_mle = (Xm.T @ Xm) / n
    eps = 1e-10
    Sigma_mle = Sigma_mle + eps * np.eye(d)
    return rng.multivariate_normal(mean=mu, cov=Sigma_mle, size=n)


# -----------------------
# Existing Phase-1 style state decoding (optional)
# -----------------------
def _rolling_last_state(hmm: GaussianHMM, X_all: np.ndarray, n_train: int) -> np.ndarray:
    Q = np.empty(len(X_all), dtype=int)
    Q[:n_train] = hmm.predict(X_all[:n_train])

    n_oos = len(X_all) - n_train
    for j in range(1, n_oos + 1):
        end = n_train + j
        start = end - WINDOW_SIZE
        Q[end - 1] = hmm.predict(X_all[start:end])[-1]
    return Q


# -----------------------
# PIT-based diagnostics (same as before)
# -----------------------
def _one_step_predictive_pit_mahalanobis(hmm: GaussianHMM, X: np.ndarray) -> np.ndarray:
    """
    Training-only PIT proxy using mixture over next-state probabilities and Chi-square CDF of
    state-wise Mahalanobis distance. Robust to singular/near-singular covariances.
    """
    from scipy.stats import chi2

    T, d = X.shape
    A = hmm.transmat_
    gamma = hmm.predict_proba(X)  # FB smoothing on training block
    means = hmm.means_
    covars = hmm.covars_

    # --- robust inverse for each state's covariance ---
    inv_cov = np.zeros_like(covars, dtype=float)
    eps_base = 1e-10

    for j in range(hmm.n_components):
        Sj = np.asarray(covars[j], dtype=float)

        # add ridge that scales with trace to avoid scale issues
        ridge = eps_base * (np.trace(Sj) / max(d, 1.0) + 1.0)
        Sj_reg = Sj + ridge * np.eye(d)

        try:
            inv_cov[j] = np.linalg.inv(Sj_reg)
        except np.linalg.LinAlgError:
            inv_cov[j] = np.linalg.pinv(Sj_reg)

    u = []
    for t in range(1, T):
        p_next = gamma[t - 1] @ A
        x = X[t]

        md2 = np.empty(hmm.n_components, dtype=float)
        for j in range(hmm.n_components):
            dx = x - means[j]
            md2[j] = float(dx.T @ inv_cov[j] @ dx)

        cdf_vals = chi2.cdf(md2, df=d)
        u_t = float(np.clip(np.sum(p_next * cdf_vals), 1e-12, 1 - 1e-12))
        u.append(u_t)

    return np.asarray(u, dtype=float)



# -----------------------
# Parametric bootstrap LR test
# -----------------------
def bootstrap_lr_test(
    X_train: np.ndarray,
    null_model: dict,
    alt_model: dict,
    n_boot: int = 200,
    rng_seed: int = 123,
) -> dict:
    """
    Parametric bootstrap LR test for HMMs (or Gaussian vs HMM).

    null_model / alt_model format:
      {"type": "gaussian"}  OR {"type": "hmm", "k": 2, "seeds": [...]}.

    Returns dict with LR_obs, p_value, LR_boot (array), and fit diagnostics.
    """
    rng = np.random.default_rng(rng_seed)

    # Fit on observed data: null and alt
    if null_model["type"] == "gaussian":
        ll_null = _ll_gaussian_mvn(X_train)
        null_fit = None
    else:
        hmm0, ll_null = _fit_hmm_best_ll(null_model["k"], X_train, null_model["seeds"])
        null_fit = hmm0

    if alt_model["type"] == "gaussian":
        ll_alt = _ll_gaussian_mvn(X_train)
        alt_fit = None
    else:
        hmm1, ll_alt = _fit_hmm_best_ll(alt_model["k"], X_train, alt_model["seeds"])
        alt_fit = hmm1

    lr_obs = 2.0 * (ll_alt - ll_null)

    # Bootstrap under null
    lr_boot = np.empty(n_boot, dtype=float)
    fail_count = 0

    for b in range(n_boot):
        try:
            if null_model["type"] == "gaussian":
                Xb = _simulate_from_gaussian(X_train, rng)
                ll0_b = _ll_gaussian_mvn(Xb)
            else:
                # hmmlearn sample returns (X, states)
                Xb, _ = null_fit.sample(X_train.shape[0], random_state=rng.integers(0, 2**31 - 1))
                Xb = np.asarray(Xb, dtype=float)
                # refit null on bootstrap sample
                _, ll0_b = _fit_hmm_best_ll(null_model["k"], Xb, null_model["seeds"])

            # fit alternative on bootstrap sample
            if alt_model["type"] == "gaussian":
                ll1_b = _ll_gaussian_mvn(Xb)
            else:
                _, ll1_b = _fit_hmm_best_ll(alt_model["k"], Xb, alt_model["seeds"])

            lr_boot[b] = 2.0 * (ll1_b - ll0_b)

        except Exception:
            # mark as NaN and count failures; we'll drop NaNs
            lr_boot[b] = np.nan
            fail_count += 1

    lr_boot_clean = lr_boot[~np.isnan(lr_boot)]
    # +1 correction for stability
    pval = (1.0 + np.sum(lr_boot_clean >= lr_obs)) / (len(lr_boot_clean) + 1.0)

    return {
        "lr_obs": float(lr_obs),
        "p_value": float(pval),
        "n_boot_requested": int(n_boot),
        "n_boot_used": int(len(lr_boot_clean)),
        "n_boot_failed": int(fail_count),
        "lr_boot": lr_boot_clean,
        "ll_null_obs": float(ll_null),
        "ll_alt_obs": float(ll_alt),
    }


# -----------------------
# Main runner
# -----------------------
def run_diagnostics_with_bootstrap():
    OUTDIR.mkdir(parents=True, exist_ok=True)

    exog = pd.read_csv(PROCESSED / "exog_rets.csv", index_col=0, parse_dates=[0])
    n_train = int((exog.index < TRAIN_DATE).sum())

    # Data blocks
    X2 = exog[["SPXT", "LT11TRUU"]].to_numpy(dtype=float)[:n_train]
    X4 = exog.to_numpy(dtype=float)[:n_train]

    # Quick GOF / residual tests for the "chosen" q=2 and q=4 (as in your Phase 1)
    summary_rows = []

    for n_states, X_train, cols in [
        (2, X2, ["SPXT", "LT11TRUU"]),
        (4, X4, list(exog.columns)),
    ]:
        seeds = _candidate_seeds(n_states, top_k=10)
        hmm, ll = _fit_hmm_best_ll(n_states, X_train, seeds)
        
        conds = []
        for j in range(hmm.n_components):
            Sj = np.asarray(hmm.covars_[j], dtype=float)
            try:
                cond = float(np.linalg.cond(Sj))
            except Exception:
                cond = np.inf
            conds.append(cond)
        
        pd.DataFrame({"state": range(hmm.n_components), "cond": conds}).to_csv(
            OUTDIR / f"cov_condition_q{n_states}.csv", index=False
        )

        # PIT + tests
        u = _one_step_predictive_pit_mahalanobis(hmm, X_train)
        ks = kstest(u, "uniform")
        z = norm.ppf(u)

        lbz = acorr_ljungbox(z, lags=[10, 20], return_df=True)
        lbz2 = acorr_ljungbox(z**2, lags=[10, 20], return_df=True)
        arch = het_arch(z, nlags=10)

        # Normality per regime per variable (train decoding)
        Q_train = hmm.predict(X_train)
        jb_rows = []
        for s in range(n_states):
            idx = np.where(Q_train == s)[0]
            if len(idx) < 20:
                continue
            Xs = X_train[idx]
            for k, col in enumerate(cols):
                jb = jarque_bera(Xs[:, k])
                jb_rows.append({"state": s, "series": col, "jb_stat": jb.statistic, "jb_pvalue": jb.pvalue})
        jb_df = pd.DataFrame(jb_rows)

        pd.DataFrame({"u": u, "z": z}).to_csv(OUTDIR / f"pit_train_q{n_states}.csv", index=False)
        jb_df.to_csv(OUTDIR / f"jb_by_state_train_q{n_states}.csv", index=False)

        summary_rows.append({
            "model": f"HMM_q{n_states}",
            "n_states": n_states,
            "seed_used": seeds[0] if len(seeds) else None,
            "train_ll": float(ll),
            "ks_pvalue": float(ks.pvalue),
            "lb_pvalue_lag10": float(lbz.loc[10, "lb_pvalue"]),
            "lb_pvalue_lag20": float(lbz.loc[20, "lb_pvalue"]),
            "lb2_pvalue_lag10": float(lbz2.loc[10, "lb_pvalue"]),
            "lb2_pvalue_lag20": float(lbz2.loc[20, "lb_pvalue"]),
            "arch_lm_pvalue": float(arch[1]),
        })

    # -----------------------
    # Bootstrap LR tests
    # -----------------------
    N_BOOT = 200  # increase for more stable p-values (compute cost rises)
    BOOT_SEED = 2026

    # (A) 2D: Gaussian (K=1) vs HMM(K=2) on [SPXT, LT11TRUU]
    lr_1v2_2d = bootstrap_lr_test(
        X_train=X2,
        null_model={"type": "gaussian"},
        alt_model={"type": "hmm", "k": 2, "seeds": _candidate_seeds(2, top_k=10)},
        n_boot=N_BOOT,
        rng_seed=BOOT_SEED,
    )
    pd.DataFrame({"lr": lr_1v2_2d["lr_boot"]}).to_csv(OUTDIR / "lr_boot_1v2_2d.csv", index=False)

    # (B) 4D: Gaussian (K=1) vs HMM(K=4) on all exog
    lr_1v4_4d = bootstrap_lr_test(
        X_train=X4,
        null_model={"type": "gaussian"},
        alt_model={"type": "hmm", "k": 4, "seeds": _candidate_seeds(4, top_k=10)},
        n_boot=N_BOOT,
        rng_seed=BOOT_SEED + 1,
    )
    pd.DataFrame({"lr": lr_1v4_4d["lr_boot"]}).to_csv(OUTDIR / "lr_boot_1v4_4d.csv", index=False)

    # (C) 4D: HMM(K=2) vs HMM(K=4) on all exog (nested, valid LR bootstrap)
    lr_2v4_4d = bootstrap_lr_test(
        X_train=X4,
        null_model={"type": "hmm", "k": 2, "seeds": _candidate_seeds(2, top_k=10)},
        alt_model={"type": "hmm", "k": 4, "seeds": _candidate_seeds(4, top_k=10)},
        n_boot=N_BOOT,
        rng_seed=BOOT_SEED + 2,
    )
    pd.DataFrame({"lr": lr_2v4_4d["lr_boot"]}).to_csv(OUTDIR / "lr_boot_2v4_4d.csv", index=False)

    lr_summary = pd.DataFrame([
        {"test": "K=1 Gaussian vs K=2 HMM (2D)", **{k: v for k, v in lr_1v2_2d.items() if k != "lr_boot"}},
        {"test": "K=1 Gaussian vs K=4 HMM (4D)", **{k: v for k, v in lr_1v4_4d.items() if k != "lr_boot"}},
        {"test": "K=2 HMM vs K=4 HMM (4D)", **{k: v for k, v in lr_2v4_4d.items() if k != "lr_boot"}},
    ])
    lr_summary.to_csv(OUTDIR / "bootstrap_lr_summary.csv", index=False)

    # Final summary
    pd.DataFrame(summary_rows).to_csv(OUTDIR / "phase1_gof_summary.csv", index=False)

    print("Wrote diagnostics to:", OUTDIR)
    print("Key files:")
    print(" - phase1_gof_summary.csv")
    print(" - bootstrap_lr_summary.csv")
    print(" - lr_boot_*.csv (bootstrap LR distributions)")


if __name__ == "__main__":
    run_diagnostics_with_bootstrap()
