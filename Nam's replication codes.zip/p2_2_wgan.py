from os import environ
from pathlib import Path
from datetime import datetime

import numpy as np
import tensorflow as tf
from tensorflow import config, random

from keras.optimizers import Adam
from keras.utils import set_random_seed
from pandas import DataFrame
from matplotlib.pyplot import figure, plot, legend, axhline, xlabel, ylabel, axvspan, gcf, close

from p2_0_utils import *


BASE_DIR = Path(r"C:\Users\namho\Desktop\Previous PC\World Quant\Thesis\Replication")
INPUT_DIR = BASE_DIR / "Inputs"


def _ols_slope_last_n(y_last_n: np.ndarray) -> float:
    """OLS slope with intercept for x = 0..n-1.

    This matches sklearn LinearRegression(fit_intercept=True) slope on that x.
    """
    y = np.asarray(y_last_n, dtype=np.float64)
    n = y.shape[0]
    x = np.arange(n, dtype=np.float64)
    xc = x - x.mean()
    yc = y - y.mean()
    den = np.dot(xc, xc)
    if den == 0.0:
        return 0.0
    return float(np.dot(xc, yc) / den)


def p2_2_wgan(n_states=1, n_stocks=8):
    SEED = 42
    TRAIN_DATE = '2009-06-02'
    Z_DIM = 128
    C_LEARN_RATE = 1e-4
    G_LEARN_RATE = 1e-4
    C_BETA_1 = 0.5
    C_BETA_2 = 0.9
    G_BETA_1 = 0.5
    G_BETA_2 = 0.9
    WINDOW_SIZE = 256
    N_ITERS = 2000
    BATCH_SIZE = 32
    N_CRITIC = 5
    LAMBDA = 10
    LOG_EVERY = 50  # throttle console I/O + reporting
    FOLDER = BASE_DIR / 'phase_2'

    environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
    set_random_seed(SEED)
    config.experimental.enable_op_determinism()

    states, stock_rets = stock_load(BASE_DIR / f'phase_1/stock_rets_q{n_states}.csv', n_stocks)
    n_train = sum(stock_rets.index < TRAIN_DATE)
    windows = range(len(stock_rets[n_train:]))

    Path(BASE_DIR / 'models').mkdir(parents=True, exist_ok=True)
    report = []

    def _print_status(state, window, data_size, iteration, c_loss, c_losses_m, c_losses_sd, lin_grad):
        print(
            f'Q: {state} of {states[-1]} |',
            f'W: {window:4d} of {windows[-1]} |',
            f'N: {data_size:4d} |',
            f'I: {iteration:4d} of {N_ITERS - 1} |',
            f'C: {c_loss:{" " if c_loss > 0 else ""}.4f} |',
            f'M: {c_losses_m:{" " if c_losses_m > 0 else ""}.4f} |',
            f'S: {c_losses_sd:4f} |',
            f'G: {lin_grad:4f} |',
            datetime.now().replace(microsecond=0)
        )

    for state in states:
        c_net = critic(n_stocks)
        g_net = generator(Z_DIM, n_stocks)

        c_opt = Adam(C_LEARN_RATE, C_BETA_1, C_BETA_2)
        g_opt = Adam(G_LEARN_RATE, G_BETA_1, G_BETA_2)

        # Wrap the full update step (N_CRITIC critic updates + 1 generator update)
        # in a compiled graph to reduce Python overhead.
        @tf.function(reduce_retracing=True)
        def train_step(real_data):
            real_data = tf.cast(real_data, tf.float32)

            c_loss_t = tf.constant(0.0, dtype=tf.float32)
            for _ in range(N_CRITIC):
                z = random.normal((BATCH_SIZE, Z_DIM))
                fake_data = g_net(z, training=True)
                with tf.GradientTape() as tape:
                    real_score = c_net(real_data, training=True)
                    fake_score = c_net(fake_data, training=True)
                    c_cost = reduce_mean(fake_score) - reduce_mean(real_score)
                    c_loss_t = c_cost + LAMBDA * grad_penalty(real_data, fake_data, c_net)
                c_grad = tape.gradient(c_loss_t, c_net.trainable_variables)
                c_opt.apply_gradients(zip(c_grad, c_net.trainable_variables))

            z = random.normal((BATCH_SIZE, Z_DIM))
            with tf.GradientTape() as tape:
                fake_data = g_net(z, training=True)
                fake_score = c_net(fake_data, training=True)
                g_loss_t = -reduce_mean(fake_score)
            g_grad = tape.gradient(g_loss_t, g_net.trainable_variables)
            g_opt.apply_gradients(zip(g_grad, g_net.trainable_variables))

            return c_loss_t, g_loss_t

        c_losses, c_losses_m, c_losses_sd, lin_grad = [], np.nan, np.nan, np.nan

        for window in windows:
            window_data = window_load(stock_rets, window, n_train, WINDOW_SIZE)
            state_data = window_data[window_data.STATE == state].drop('STATE', axis=1).values
            data_size = len(state_data)

            last_iteration, last_c_loss, last_g_loss = 0, np.nan, np.nan

            # No data in this state-window: record once and move on.
            if data_size == 0:
                report.append({
                    'STATE': state,
                    'WINDOW': window,
                    'LENGTH': data_size,
                    'ITERATION': 0,
                    'C_LOSS': last_c_loss,
                    'G_LOSS': last_g_loss
                })
                _print_status(state, window, data_size, 0, last_c_loss, c_losses_m, c_losses_sd, lin_grad)
                g_net.save_weights(BASE_DIR / 'models' / f'w{window}_s{state}_q{n_states}.weights.h5')
                continue

            for iteration in range(N_ITERS):
                # Sample a minibatch (keep logic identical to original)
                real_data = state_data[choice(data_size, BATCH_SIZE)]

                # Train
                c_loss_t, g_loss_t = train_step(real_data)

                # Scalars for control logic / reporting
                last_c_loss = float(c_loss_t.numpy())
                last_g_loss = float(g_loss_t.numpy())
                last_iteration = iteration

                c_losses.append(last_c_loss)
                c_losses_m = float(mean(c_losses[-100:]))
                c_losses_sd = float(std(c_losses[-100:]))

                # Replace sklearn LinearRegression with closed-form OLS slope (same model).
                if len(c_losses) >= 100:
                    lin_grad = abs(_ols_slope_last_n(np.asarray(c_losses[-100:], dtype=np.float64)))
                else:
                    lin_grad = np.nan

                # Report handling:
                # - Keep full per-iteration report for window 0 (used for detailed plots)
                # - For other windows, only keep the terminal row (added after the loop)
                if window == 0:
                    report.append({
                        'STATE': state,
                        'WINDOW': window,
                        'LENGTH': data_size,
                        'ITERATION': iteration,
                        'C_LOSS': last_c_loss,
                        'G_LOSS': last_g_loss
                    })

                # Throttled printing: every LOG_EVERY steps, plus always print when we break.
                should_print = (iteration == 0) or (iteration % LOG_EVERY == 0)

                if break_check(window, iteration, c_losses_m, c_losses_sd, lin_grad):
                    _print_status(state, window, data_size, iteration, last_c_loss, c_losses_m, c_losses_sd, lin_grad)
                    break

                if should_print:
                    _print_status(state, window, data_size, iteration, last_c_loss, c_losses_m, c_losses_sd, lin_grad)

            # For windows > 0, store only the terminal row (used later via iloc[-1]).
            if window != 0:
                report.append({
                    'STATE': state,
                    'WINDOW': window,
                    'LENGTH': data_size,
                    'ITERATION': last_iteration,
                    'C_LOSS': last_c_loss,
                    'G_LOSS': last_g_loss
                })

            g_net.save_weights(BASE_DIR / 'models' / f'w{window}_s{state}_q{n_states}.h5')

    # PLOT >============================================================================================================

    loss_report = DataFrame(report)

    plt_loss_w0, plt_loss = [], []
    for state in states:
        loss_q = loss_report[loss_report.STATE == state]

        loss_q_w0 = loss_q[loss_q.WINDOW == 0]
        c_loss_q_w0 = loss_q_w0.C_LOSS.to_list()
        g_loss_q_w0 = loss_q_w0.G_LOSS.to_list()

        loss_q_w = loss_q[loss_q.WINDOW != 0]
        c_loss_q_w = [loss_q[loss_q.WINDOW == window].iloc[-1].C_LOSS for window in unique(loss_q_w.WINDOW)]
        g_loss_q_w = [loss_q[loss_q.WINDOW == window].iloc[-1].G_LOSS for window in unique(loss_q_w.WINDOW)]

        figure(figsize=(4, 3))
        plot(c_loss_q_w0, lw=0.3, c='c')
        plot(g_loss_q_w0, lw=0.3, c='g')
        legend(labels=['Critic Loss', 'Generator Loss'])
        axhline(lw=0.5, c='k')
        xlabel('Iteration')
        ylabel('Loss')
        plt_loss_w0.append(gcf())
        close()

        figure(figsize=(4, 3))
        plot(c_loss_q_w0 + c_loss_q_w, lw=0.3, c='c')
        plot(g_loss_q_w0 + g_loss_q_w, lw=0.3, c='g')
        axvspan(0, len(c_loss_q_w0), color='grey', alpha=0.2)
        legend(labels=['Critic Loss', 'Generator Loss', 'Training Window'])
        axhline(lw=0.5, c='k')
        xlabel('Iteration')
        ylabel('Loss')
        plt_loss.append(gcf())
        close()

    # PLOT <============================================================================================================

    Path(FOLDER).mkdir(parents=True, exist_ok=True)
    loss_report.to_csv(FOLDER / f'loss_report_q{n_states}_n{n_stocks}.csv', index=False)
    stock_rets.to_csv(FOLDER / f'stock_rets_q{n_states}_n{n_stocks}.csv')
    for state in states:
        plt_loss_w0[state].savefig(FOLDER / f'plt_loss_w0_s{state}_q{n_states}_n{n_stocks}.pdf', bbox_inches='tight')
        plt_loss[state].savefig(FOLDER / f'plt_loss_s{state}_q{n_states}_n{n_stocks}.pdf', bbox_inches='tight')


if __name__ == '__main__':
    p2_2_wgan()
